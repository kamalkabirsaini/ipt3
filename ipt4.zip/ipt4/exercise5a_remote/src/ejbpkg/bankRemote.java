/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejbpkg;

import javax.ejb.Remote;

/**
 *
 * @author amank
 */
@Remote
public interface bankRemote {

    void withdraw(int amount);

    void deposit(int depamount);

    int balance();
    
}
